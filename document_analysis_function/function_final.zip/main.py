import os
from google.cloud import firestore
from google.cloud import documentai_v1beta3 as documentai
from google.cloud import storage
import vertexai
from vertexai.generative_models import GenerativeModel, Part
import traceback

# This is the corrected function definition. It now correctly accepts both 'event' and 'context'.
def process_medical_bill(event, context):
    """
    Cloud Function triggered by a file upload to a specific GCS bucket.
    This function orchestrates the analysis of a medical bill.
    """
    try:
        print("--- Function execution started. ---")

        # --- 1. GET ENVIRONMENT VARIABLES ---
        gcp_project_id = os.environ.get('GCP_PROJECT_ID')
        docai_processor_id = os.environ.get('DOCAI_PROCESSOR_ID')
        docai_location = os.environ.get('DOCAI_LOCATION', 'us')

        print(f"--- GCP_PROJECT_ID: {gcp_project_id} ---")
        print(f"--- DOCAI_PROCESSOR_ID: {docai_processor_id} ---")
        print(f"--- DOCAI_LOCATION: {docai_location} ---")

        if not all([gcp_project_id, docai_processor_id, docai_location]):
            raise ValueError("FATAL ERROR: One or more environment variables are not set.")

        # --- 2. INITIALIZE CLIENTS ---
        print("--- Initializing clients... ---")
        firestore_client = firestore.Client(project=gcp_project_id)
        storage_client = storage.Client(project=gcp_project_id)
        vertexai.init(project=gcp_project_id, location="us-central1")
        docai_client = documentai.DocumentProcessorServiceClient(
            client_options={"api_endpoint": f"{docai_location}-documentai.googleapis.com"}
        )
        print("--- All clients initialized successfully. ---")

        # --- 3. EXTRACT FILE INFO FROM TRIGGER EVENT ---
        bucket_name = event['bucket']
        file_name = event['name']
        print(f"--- Triggered by file: {file_name} in bucket: {bucket_name} ---")

        parts = file_name.split('/')
        if len(parts) < 3 or parts[0] != 'user_uploads':
            print(f"--- ERROR: File {file_name} is not in the expected 'user_uploads/{{uid}}/' directory structure. ---")
            return

        uid = parts[1]
        original_filename = parts[2]
        gcs_uri = f"gs://{bucket_name}/{file_name}"
        
        print(f"--- Processing for user ID: {uid}, GCS URI: {gcs_uri} ---")

        # --- 4. PARSING THE PDF WITH DOCUMENT AI ---
        print("--- Starting Document AI processing. ---")
        
        bucket = storage_client.get_bucket(bucket_name)
        blob = bucket.get_blob(file_name)
        if not blob:
            raise FileNotFoundError(f"Could not find file {file_name} in bucket {bucket_name}.")
            
        file_content = blob.download_as_bytes()
        mime_type = blob.content_type

        resource_name = docai_client.processor_path(gcp_project_id, docai_location, docai_processor_id)
        raw_document = documentai.RawDocument(content=file_content, mime_type=mime_type)
        request = documentai.ProcessRequest(name=resource_name, raw_document=raw_document)

        result = docai_client.process_document(request=request)
        extracted_text = result.document.text
        
        print("--- Document AI processing successful. ---")

        # --- 5. ANALYZING THE CONTENT WITH GEMINI ---
        print("--- Starting analysis with Gemini. ---")
        
        model = GenerativeModel("gemini-1.5-pro-preview-0409")
        
        prompt = f"""
        You are an expert AI assistant specializing in U.S. medical billing.
        Your task is to analyze the text extracted from a medical document and return a structured JSON output.

        DOCUMENT TEXT:
        ---
        {extracted_text}
        ---

        Based on the document text, perform the following actions:
        1.  Extract the following key-value pairs. If a value is not found, use "Not Found".
            - "patient_name"
            - "provider_name"
            - "total_amount_due"
            - "statement_date"
            - "account_number"
        2.  Create a "concise_summary" of the services rendered in one or two sentences.
        3.  Perform an "initial_analysis". Identify any potential red flags such as duplicate charges, services that seem unusually expensive, or items that are typically not covered. If no red flags are found, state that.

        Return ONLY a valid JSON object with the keys "key_information", "concise_summary", and "initial_analysis".
        """
        
        response = model.generate_content(prompt)
        analysis_json = response.text
        
        print("--- Gemini analysis successful. ---")
        
        # --- 6. SAVING THE ANALYSIS TO FIRESTORE ---
        print("--- Saving analysis to Firestore. ---")
        
        user_ref = firestore_client.collection('users').document(uid)
        analyses_collection = user_ref.collection('analyses')
        
        new_analysis_doc = {
            'analysis_results': analysis_json,
            'original_filename': original_filename,
            'gcs_uri': gcs_uri,
            'status': 'completed',
            'created_at': firestore.SERVER_TIMESTAMP
        }
        
        doc_ref = analyses_collection.add(new_analysis_doc)
        
        print(f"--- Analysis saved successfully to Firestore for user {uid} with document ID: {doc_ref[1].id} ---")
        print("--- Function execution finished successfully. ---")

    except Exception as e:
        print("--- AN UNHANDLED ERROR OCCURRED ---")
        traceback.print_exc()
        
        try:
            parts = event.get('name', '').split('/')
            if len(parts) >= 3:
                uid = parts[1]
                original_filename = parts[2]
                gcs_uri = f"gs://{event.get('bucket')}/{event.get('name')}"
                
                if 'firestore_client' not in locals():
                    gcp_project_id = os.environ.get('GCP_PROJECT_ID')
                    firestore_client = firestore.Client(project=gcp_project_id)

                user_ref = firestore_client.collection('users').document(uid)
                analyses_collection = user_ref.collection('analyses')
                analyses_collection.add({
                    'original_filename': original_filename,
                    'gcs_uri': gcs_uri,
                    'status': 'failed',
                    'error_message': str(e),
                    'created_at': firestore.SERVER_TIMESTAMP
                })
                print("--- Failure record saved to Firestore. ---")
        except Exception as fe:
            print(f"--- Could not save failure record to Firestore. Error: {fe} ---")
